/*
miniz public domain replacement for zlib. See miniz.c
for more information.
*/
#ifndef MINIZ_HEADER_FILE_ONLY
#define MINIZ_HEADER_FILE_ONLY
#include "miniz.c"
#endif //MINIZ_HEADER_FILE_ONLY