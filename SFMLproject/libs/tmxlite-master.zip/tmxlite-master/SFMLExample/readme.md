SFML Example
------------

Test program demonstrating how one may possibly implement
an orthogonal map renderer using SFML